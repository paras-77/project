package drawable.Downloads.form.app.src.main.java.com.example.kartik.form;

import android.support.v7.app.ActionBarActivity;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.TextView;


public class displa_form extends ActionBarActivity {

    TextView t1,t2,t3,t4;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_displa_form);
        String uname=getIntent().getStringExtra("name");
        String uage=getIntent().getStringExtra("age");
        String uaddress=getIntent().getStringExtra("address");
        String ugender=getIntent().getStringExtra("gender");

        t1= (TextView) findViewById(R.id.name);
        t2= (TextView) findViewById(R.id.age);
        t3= (TextView) findViewById(R.id.address);
        t4= (TextView) findViewById(R.id.gender);

        t1.setText(uname);
        t2.setText(uage);
        t3.setText(uaddress);
        t4.setText(ugender);



    }


    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_displa_form, menu);
        return true;
    }

0    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        }

        return super.onOptionsItemSelected(item);
    }
}
