package com.example.dell.powerchat;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.net.Uri;
import android.support.v7.app.ActionBarActivity;
import android.os.Bundle;
import android.view.Gravity;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TableLayout;
import android.widget.TableRow;
import android.widget.TextView;
import android.widget.Toast;

import java.io.ByteArrayOutputStream;
import java.io.FileNotFoundException;
import java.io.InputStream;


public class status extends ActionBarActivity {
    String r_nm, r_lnm,r_num;
    Cursor c,c1,c2;
    int r_id;
    db_helper db;
    SQLiteDatabase database;
    ImageView img,user;
    public byte[] byteArray;
    private static int RESULT_LOAD_IMAGE = 1;
    Button btn;
    byte[] blob;
    int rid;
    SharedPreferences sp;
    int id;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_status);
        db_helper db = new db_helper(this);
        img=(ImageView)findViewById(R.id.imageView4);
        user=(ImageView)findViewById(R.id.user);
        btn=(Button)findViewById(R.id.button2);
        sp=getSharedPreferences("friends", Context.MODE_PRIVATE);
        id=sp.getInt("s_id", 0);
        try {
            c = db.profile();
            if (c.moveToFirst()) {
                do {
                    blob = c.getBlob(c.getColumnIndex("r_image"));
                    rid = c.getInt(c.getColumnIndex("r_id"));

                    if (id == rid) {
                        Bitmap bmp = BitmapFactory.decodeByteArray(blob, 0, blob.length);
                        Bitmap.createScaledBitmap(bmp, 50, 50, true);
                        user.setImageBitmap(bmp);
                    }
                } while (c.moveToNext());
            } else {
            }
        }catch(Exception e)
        {
            Toast.makeText(getApplicationContext(),"NO DATA FOUND"+e.getMessage(), Toast.LENGTH_LONG).show();
        }



        TableLayout tab_lay = (TableLayout) findViewById(R.id.tab_lay);
        int i = 0;
        byte[] blob;
            try {
                c1 = db.status_display();
                if (c1.moveToFirst()) {
                    do {
                        r_nm = c1.getString(c.getColumnIndex("r_nm"));
                        r_lnm = c1.getString(c.getColumnIndex("r_lnm"));
                        blob = c1.getBlob(c.getColumnIndex("r_image"));
                        r_id = c1.getInt(c.getColumnIndex("r_id"));

                        if(id!=r_id) {
                            TableRow a = new TableRow(this);
                            TableRow.LayoutParams param = new TableRow.LayoutParams(TableRow.LayoutParams.FILL_PARENT, TableRow.LayoutParams.MATCH_PARENT, 1.0f);
                            a.setLayoutParams(param);
                            Bitmap bmp = BitmapFactory.decodeByteArray(blob, 0, blob.length);
                            TableRow.LayoutParams param1 = new TableRow.LayoutParams(100, 100);
                            Bitmap.createScaledBitmap(bmp, 50, 50, true);
                            final ImageView imgview = new ImageView(this);
                            imgview.setId(i);
                            imgview.setPadding(10, 10, 10, 10);
                            imgview.setImageBitmap(bmp);
                            imgview.setTag(r_id);
                            imgview.setLayoutParams(param1);
                            final TextView nm = new TextView(this);
                            nm.setText(r_nm + "   " + r_lnm);
                            nm.setTag(r_id);
                            nm.setId(i);
                            nm.setTextColor(Color.WHITE);
                            nm.setTextSize(20);
                            nm.setHeight(60);
                            nm.setPadding(0, 10, 0, 0);
                            nm.setGravity(Gravity.CENTER_VERTICAL);
                            nm.setOnClickListener(new View.OnClickListener() {
                                @Override
                                public void onClick(View v) {
                                    SharedPreferences sp = getSharedPreferences("profile", MODE_PRIVATE);
                                    SharedPreferences.Editor ed = sp.edit();
                                    String rid = String.valueOf(v.getTag());
                                    int r = Integer.parseInt(rid);
                                    ed.putInt("status", r);
                                    ed.commit();
                                    Intent i = new Intent(getApplicationContext(), show_story.class);
                                    startActivity(i);
                                }
                            });
                            imgview.setOnClickListener(new View.OnClickListener() {
                                @Override
                                public void onClick(View v) {
                                    SharedPreferences sp = getSharedPreferences("profile", MODE_PRIVATE);
                                    SharedPreferences.Editor ed = sp.edit();
                                    String rid = String.valueOf(v.getTag());
                                    int r = Integer.parseInt(rid);
                                    ed.putInt("status", r);
                                    ed.commit();
                                    Intent i = new Intent(getApplicationContext(), show_story.class);
                                    startActivity(i);
                                }
                            });
                            a.addView(imgview);
                            a.addView(nm);
                            tab_lay.addView(a, i);
                            i = i + 1;
                        }
                        } while (c1.moveToNext()) ;
                    }
              }catch(Exception e)
            {
                Toast.makeText(getApplicationContext(),"NO DATA FOUND"+e.getMessage(), Toast.LENGTH_LONG).show();
            }
    }


    public void status(View v)
    {
        SharedPreferences sp1 = getSharedPreferences("profile", MODE_PRIVATE);
        SharedPreferences.Editor ed = sp1.edit();
        ed.putInt("status", id);
        ed.commit();

        Intent i=new Intent(getApplicationContext(),show_story.class);
        startActivity(i);
        finish();
    }

    public void send_story(View v)
    {
        db_helper db = new db_helper(this);
        SharedPreferences sp1 = getSharedPreferences("profile", MODE_PRIVATE);
        SharedPreferences.Editor ed = sp1.edit();
        ed.putInt("status", id);
        ed.commit();
        if(db.add_status(id,byteArray))
        {
            Intent i=new Intent(getApplicationContext(),show_story.class);
            startActivity(i);
            finish();
        }
        else
        {
            Toast.makeText(getApplicationContext(),"error in story addition",Toast.LENGTH_LONG).show();
        }

    }
    public void story(View view)
    {
        Intent getImageIntent = new Intent(Intent.ACTION_GET_CONTENT);
        getImageIntent.setType("image/*");
        startActivityForResult(getImageIntent, RESULT_LOAD_IMAGE);
    }

    @Override
    public void onActivityResult(int requestCode,int resultCode, Intent data )
    {
        if(requestCode==RESULT_LOAD_IMAGE && resultCode== RESULT_OK)
        {
            try
            {
                final Uri uriImage = data.getData();
                final InputStream inputStream = getContentResolver().openInputStream(uriImage);
                final Bitmap imageMap = BitmapFactory.decodeStream(inputStream);
                img.setImageBitmap(imageMap);
                img.setVisibility(View.VISIBLE);
                ByteArrayOutputStream stream = new ByteArrayOutputStream();
                Bitmap.createScaledBitmap(imageMap,10,10,true);
                imageMap.compress(Bitmap.CompressFormat.JPEG,10,stream);
                byteArray = stream.toByteArray();
                btn.setVisibility(View.INVISIBLE);
            }
            catch (FileNotFoundException e)
            {
                e.printStackTrace();
                Toast.makeText(getApplicationContext(), "NO IMAGE FOUND", Toast.LENGTH_SHORT).show();
            }
        }
    }
}
