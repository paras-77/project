package com.example.dell.powerchat;

import android.content.SharedPreferences;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.support.v7.app.ActionBarActivity;
import android.os.Bundle;
import android.util.Base64;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.ImageView;
import android.widget.TableRow;
import android.widget.TextView;
import android.widget.Toast;

import java.io.ByteArrayInputStream;
import java.io.InputStream;
import java.sql.Blob;


public class Profile_screen extends ActionBarActivity {
    ImageView iv;
    TextView tv;
    db_helper db;
    Cursor c;
    byte[] blob;
    int rid;
    String name;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_profile_screen);
        iv=(ImageView)findViewById(R.id.pic);
        tv=(TextView)findViewById(R.id.pic_nm);
        SharedPreferences sp = getSharedPreferences("profile", MODE_PRIVATE);
        int id=sp.getInt("pic", 0);
        db=new db_helper(this);
        try {
            c = db.profile();
            if (c.moveToFirst()) {
                do {
                    blob = c.getBlob(c.getColumnIndex("r_image"));
                    rid = c.getInt(c.getColumnIndex("r_id"));

                    if (id == rid) {
                        name=c.getString(c.getColumnIndex("r_nm")) + " " + c.getString(c.getColumnIndex("r_lnm"));
                        tv.setText(name);
                        Bitmap bmp = BitmapFactory.decodeByteArray(blob, 0, blob.length);
                         Bitmap.createScaledBitmap(bmp, 50, 50, true);
                         iv.setImageBitmap(bmp);
                  }
                } while (c.moveToNext());
            } else {
            }
        }catch(Exception e)
        {
            Toast.makeText(getApplicationContext(),"NO DATA FOUND"+e.getMessage(), Toast.LENGTH_LONG).show();
        }
    }
}
