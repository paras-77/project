package com.example.dell.powerchat;

import android.content.Intent;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.support.v7.app.ActionBarActivity;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;


public class Edit_profile extends ActionBarActivity {
    String r_nm, r_lnm,r_num,r_email;
    public static Cursor c;
    int s_id,r_id;
    db_helper db;
    EditText nm,lnm,num,email;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_edit_profile);
        nm=(EditText)findViewById(R.id.textView9);
        lnm=(EditText)findViewById(R.id.textView10);
        num=(EditText)findViewById(R.id.textView11);
        email=(EditText)findViewById(R.id.textView12);
        SharedPreferences sp = getSharedPreferences("friends", MODE_PRIVATE);
        s_id = sp.getInt("s_id", 0);
        db = new db_helper(this);
        try {
            c = db.chatlist();
            if (c.moveToFirst()) {
                do {
                    r_id=c.getInt(c.getColumnIndex("r_id"));
                    r_nm=c.getString(c.getColumnIndex("r_nm"));
                    r_lnm=c.getString(c.getColumnIndex("r_lnm"));
                    r_num=c.getString(c.getColumnIndex("r_num"));
                    r_email=c.getString(c.getColumnIndex("r_email"));
                    if(s_id==r_id)
                    {
                        nm.setText(r_nm);
                        lnm.setText(r_lnm);
                        num.setText(r_num);
                        email.setText(r_email);
                    }

                } while (c.moveToNext());
            }
        } catch (Exception e) {
            Toast.makeText(getApplicationContext(), "NO DATA FOUND" + e.getMessage(), Toast.LENGTH_LONG).show();
        }
    }

    public void save(View v) {

        String nm1,lnm1,num1,email1;
        nm1= String.valueOf(nm.getText());
        lnm1=String.valueOf(lnm.getText());
        num1=String.valueOf(num.getText());
        email1=String.valueOf(email.getText());
        if (db.Edit_profile(s_id,nm1,lnm1,num1,email1))
        {
            Toast.makeText(getApplicationContext(),"Profile Updated",Toast.LENGTH_LONG).show();
            Intent i = new Intent(getApplicationContext(), View_Profile.class);
            startActivity(i);
            finish();
        }
        else {
            Toast.makeText(getApplicationContext(),"Error in update",Toast.LENGTH_LONG).show();
        }

    }
}
