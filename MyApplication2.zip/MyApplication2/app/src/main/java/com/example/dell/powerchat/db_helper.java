package com.example.dell.powerchat;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.provider.*;
import android.provider.Contacts;
import android.view.View;
import android.widget.Toast;

import java.text.SimpleDateFormat;
import java.util.Date;

/**
 * Created by dell on 26-Feb-21.
 */
public class db_helper extends SQLiteOpenHelper {

    private static final int DATABASE_VERSION = 1;
    private static final String DATABASE_NAME = "PowerChat.db";
    private String CREATE_USER_TABLE = "CREATE TABLE registration (r_id integer primary key Autoincrement, r_nm text, r_lnm text, r_num text, r_email text, r_pwd text, r_image blob )";
    private String CREATE_CHAT_TABLE = "CREATE TABLE chat (chat_id integer primary key Autoincrement, chat_sid integer, chat_rid integer, chat_msg text, chat_time text, chat_date text,chat_s integer,chat_r integer)";
    private String CREATE_STATUS_TABLE = "CREATE TABLE status (status_id integer primary key Autoincrement, status_sid integer, status_image blob)";
    private String CREATE_BLOCK_TABLE="create table block(b_id integer primary key Autoincrement,s_id integer,r_id integer)";

    public db_helper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    public boolean AddData(String nm, String lnm, String num, String email, String pwd,byte[] profile) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues cv = new ContentValues();
        cv.put("r_nm", nm);
        cv.put("r_lnm", lnm);
        cv.put("r_num", num);
        cv.put("r_email", email);
        cv.put("r_pwd", pwd);
        cv.put("r_image", profile);
        long ans = db.insert("registration", null, cv);
        if (ans != -1) {
            return true;
        } else {
            return false;
        }
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL(CREATE_USER_TABLE);
        db.execSQL(CREATE_CHAT_TABLE);
        db.execSQL(CREATE_STATUS_TABLE);
        db.execSQL(CREATE_BLOCK_TABLE);

    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("Drop table if exists registration");
        db.execSQL("Drop table if exists chat");
        db.execSQL("Drop table if exists status");
        db.execSQL("Drop table if exists block");
        onCreate(db);

    }


    public Integer check_login(String unm, String pwd) {
        SQLiteDatabase db = this.getReadableDatabase();
        String sql = "select r_id from registration where r_email='" + unm + "' and r_pwd='" + pwd + "'";
        Cursor c = db.rawQuery(sql, null);
        if (c.moveToFirst()) {
            int id = c.getInt(c.getColumnIndex("r_id"));
            return id;
        } else {
            return 0;
        }
    }

    public Cursor chatlist() {
        SQLiteDatabase db = this.getReadableDatabase();
        return db.rawQuery("SELECT r_id,r_nm,r_lnm,r_num,r_email,r_image FROM registration", null);
    }
    public Cursor chatlists() {
        SQLiteDatabase db = this.getReadableDatabase();
        return db.rawQuery("SELECT r_id,r_nm,r_lnm,r_num,r_image FROM registration", null);
    }
    public Cursor profile() {
        SQLiteDatabase db = this.getReadableDatabase();
        return db.rawQuery("SELECT r_id,r_nm,r_lnm,r_image FROM registration", null);
    }

     public Cursor chat_display(int s_id)
    {
        SQLiteDatabase db= this.getReadableDatabase();
        return db.rawQuery("select  registration.r_id,registration.r_image,registration.r_nm,registration.r_lnm,chat.chat_msg,chat.chat_time from registration inner join chat where registration.r_id=chat.chat_rid and chat_sid='"+s_id+"'  group by r_id",null);
    }
    public Cursor chat_display1(int s_id)
    {
        SQLiteDatabase db= this.getReadableDatabase();
        return db.rawQuery("select  registration.r_id,registration.r_image,registration.r_nm,registration.r_lnm,chat.chat_msg,chat.chat_time from registration inner join chat where chat_sid='"+s_id+"' or chat_rid='"+s_id+"' and chat_s='0'  group by r_id",null);
    }

   public boolean message(int c_sid,int c_rid,String c_msg,String time,String date)
   {
       SQLiteDatabase db= this.getWritableDatabase();
       ContentValues cvm=new ContentValues();
       cvm.put("chat_sid",c_sid);
       cvm.put("chat_rid",c_rid);
       cvm.put("chat_msg",c_msg);
       cvm.put("chat_time",time);
       cvm.put("chat_date",date);
       cvm.put("chat_s",0);
       cvm.put("chat_r",0);
       long ans=db.insert("chat",null,cvm);
       if(ans!=-1){
           return true;

       }
       else
       {
           return false;

       }

   }
    public Cursor viewMsg(int s_id,int r_id)
    {
        SQLiteDatabase db=this.getReadableDatabase();
        return db.rawQuery("SELECT * FROM chat where chat_sid='" + s_id + "' and chat_rid='" + r_id + "' or chat_sid='" + r_id + "' and chat_rid='" + s_id + "'",null);
    }

    public boolean add_status(int s_id,byte[] story)
    {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues cv = new ContentValues();
        cv.put("status_image", story);
        cv.put("status_sid", s_id);
        long ans = db.insert("status",null,cv);
        if(ans>=0)
        {
            return true;
        }
        else
        {
            return false;

        }
    }

    public boolean delete(int r_id)
    {
        SQLiteDatabase mydb;
        mydb = this.getWritableDatabase();
        String where = "r_id='" + r_id + "'";
        long ans=mydb.delete("registration",where,null);
        if(ans!=-1)
        {
            return  true;
        }
        else
        {
            return false;
        }
    }
    public Cursor status_display()
    {
        SQLiteDatabase db= this.getReadableDatabase();
        return db.rawQuery("select r_id,r_nm,r_lnm,r_image from registration where r_id in(select status_sid from status)",null);
    }

    public Cursor view_story(int id)
    {
        SQLiteDatabase db=this.getReadableDatabase();
        return db.rawQuery("select status_id,status_sid,status_image from status where status_sid='" + id + "'",null);
    }


    public boolean add_block(int s_id,int r_id)
    {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues cv = new ContentValues();
        cv.put("s_id", s_id);
        cv.put("r_id", r_id);
        long ans = db.insert("block",null,cv);
        if(ans>=0)
        {
            return true;
        }
        else
        {
            return false;

        }
    }

    public Integer view_block(int s_id,int r_id) {
        SQLiteDatabase db = this.getReadableDatabase();
        String sql = "select b_id from block where s_id='"+s_id+"' and r_id='" + r_id + "'";
        Cursor c = db.rawQuery(sql, null);
        if (c.moveToFirst()) {
            return 1;
        } else {
            return 0;
        }
    }


    public boolean unblock(int s_id,int r_id) {
        SQLiteDatabase mydb;
        mydb = this.getWritableDatabase();
        String where = "s_id='" + s_id + "' and r_id='" +r_id +"'";
        long ans=mydb.delete("block",where,null);
        if(ans!=-1)
        {
            return  true;
        }
        else
        {
            return false;
        }
    }

    public boolean del_chat(int s_id,int r_id)
    {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues cv = new ContentValues();
        cv.put("chat_s", 1);
        String where = "chat_sid='" + s_id + "' and chat_rid='" + r_id+ "'";
        long ans = db.update("chat", cv, where, null);
        if (ans != -1) {
            return true;
        } else {
            return false;
        }
    }

    public boolean Edit_profile(int r_id,String nm, String lnm, String num, String email) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues cv = new ContentValues();
        cv.put("r_nm", nm);
        cv.put("r_lnm", lnm);
        cv.put("r_num", num);
        cv.put("r_email", email);
        String where = "r_id='" + r_id + "'";
        long ans = db.update("registration", cv, where, null);
        if (ans != -1) {
            return true;
        }
        else
        {
            return false;
        }
    }

    public Cursor deleted_chat(int s_id) {
        SQLiteDatabase db=this.getReadableDatabase();
        return db.rawQuery("select chat_s from chat where chat_sid='" + s_id + "' and chat_s='1'",null);
    }
}