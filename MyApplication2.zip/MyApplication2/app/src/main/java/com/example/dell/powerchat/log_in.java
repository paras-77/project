package com.example.dell.powerchat;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.database.sqlite.SQLiteDatabase;
import android.support.v7.app.ActionBarActivity;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.EditText;
import android.widget.TabHost;
import android.widget.Toast;


public class log_in extends ActionBarActivity {

    Boolean flag = true;
    EditText mail,pwds;
    db_helper db;
    SQLiteDatabase database;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_log_in);

        db=new db_helper(this);
        database=db.getReadableDatabase();

         mail=(EditText)findViewById(R.id.txt_email);
         pwds=(EditText)findViewById(R.id.txt_pwd);


    }
    public void registery(View v) {
        Intent i = new Intent(getBaseContext(), registery.class);
        startActivity(i);
    }


    public void login(View v) {
        String email, pwd;
        SharedPreferences sp = getSharedPreferences("friends", Context.MODE_PRIVATE);
        SharedPreferences.Editor ed = sp.edit();
        email = mail.getText().toString();
        pwd = pwds.getText().toString();
        String emailPattern = "[a-zA-Z0-9._-]+@[a-z]+\\.+[a-z]+";
        if (email.isEmpty()) {
            mail.setError("Please enter the Email");
            flag = false;
        } else if (!email.matches(emailPattern)) {
            mail.setError("Invalid Email Address");
            flag = false;
        }
        if (pwd.isEmpty()) {
            pwds.setError("Please Enter the password");
            flag = false;
        } else {
            flag = true;
        }
        if (flag == true) {


            int id = db.check_login(email, pwd);
            if (id != 0) {
                ed.putInt("s_id", id);
                ed.commit();
                Intent i = new Intent(getApplicationContext(), Home.class);
                startActivity(i);
            } else {
                Toast.makeText(getApplicationContext(), "Invalid Username Or Password", Toast.LENGTH_LONG
                ).show();
            }
        }
    }
}