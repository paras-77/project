package com.example.dell.powerchat;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.provider.ContactsContract;
import android.support.v7.app.ActionBarActivity;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.GridView;
import android.widget.ImageView;
import android.widget.TableLayout;
import android.widget.TableRow;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;


public class chat_display extends ActionBarActivity {

    String r_nm;
    public static  Cursor c,c1;
    int r_id;
    SQLiteDatabase database;
    db_helper db;
    private ArrayList<String> num,name;
    int s_id;
    String name1,lnm,msg,time;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_chat_display);
        num=new ArrayList<String>();
        name=new ArrayList<String>();
        int j=0;
        Cursor phones = getContentResolver().query(ContactsContract.CommonDataKinds.Phone.CONTENT_URI, null,null,null, null);
        while (phones.moveToNext())
        {
            String str= phones.getString(phones.getColumnIndex(ContactsContract.CommonDataKinds.Phone.NUMBER));

            name.add(phones.getString(phones.getColumnIndex(ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME)));
            num.add(str.replaceAll("[-() ]", ""));
            j++;
        }
        phones.close();
        SharedPreferences sp = getSharedPreferences("friends", MODE_PRIVATE);
        s_id = sp.getInt("s_id", 0);
        db = new db_helper(this);
        TableLayout tab_lay1 = (TableLayout) findViewById(R.id.tab_lay1);
        int i = 0;
        byte[] blob;
        try {
            c = db.chat_display1(s_id);
            if (c.moveToFirst()) {
                do {
                    TableRow a = new TableRow(this);
                    TableRow.LayoutParams param = new TableRow.LayoutParams(TableRow.LayoutParams.FILL_PARENT, TableRow.LayoutParams.MATCH_PARENT, 1.0f);
                    a.setLayoutParams(param);
                    name1 = c.getString(c.getColumnIndex("r_nm"));
                    lnm = c.getString(c.getColumnIndex("r_lnm"));
                    msg = c.getString(c.getColumnIndex("chat_msg"));
                    time = c.getString(c.getColumnIndex("chat_time"));
                    blob = c.getBlob(c.getColumnIndex("r_image"));
                    int id = c.getInt(c.getColumnIndex("r_id"));
                    if(s_id!=id)
                    {
                    int block=db.view_block(s_id,id);
                    if(block<1) {
             /*           c1=db.deleted_chat(s_id);
                        if(c1.moveToFirst())
                        {
                        }
                        else { */
                            Bitmap bmp = BitmapFactory.decodeByteArray(blob, 0, blob.length);
                            TableRow.LayoutParams param1 = new TableRow.LayoutParams(100, 100);
                            Bitmap.createScaledBitmap(bmp, 50, 50, true);
                            final ImageView imgview = new ImageView(this);
                            imgview.setId(i);
                            imgview.setImageBitmap(bmp);
                            imgview.setTag(id);
                            imgview.setLayoutParams(param1);
                            final TextView nm = new TextView(this);
                            nm.setText(name1 + "   " + lnm + "  " + time);
                            nm.setTag(id);
                            nm.setId(i);
                            nm.setTextColor(Color.WHITE);
                            nm.setTextSize(20);
                            nm.setOnClickListener(new View.OnClickListener() {
                                @Override
                                public void onClick(View v) {
                                    SharedPreferences sp = getSharedPreferences("chat", MODE_PRIVATE);
                                    SharedPreferences.Editor ed = sp.edit();
                                    String rid = String.valueOf(v.getTag());
                                    int r = Integer.parseInt(rid);
                                    ed.putInt("r_id", r);
                                    ed.putString("name", name1);
                                    ed.commit();
                                    Intent i = new Intent(getApplicationContext(), chat_screen.class);
                                    startActivity(i);
                                }
                            });

                            nm.setOnLongClickListener(new View.OnLongClickListener() {
                                @Override
                                public boolean onLongClick(View v) {
                                    SharedPreferences sp = getSharedPreferences("chat", MODE_PRIVATE);
                                    SharedPreferences.Editor ed = sp.edit();
                                    String rid = String.valueOf(v.getTag());
                                    int r = Integer.parseInt(rid);
                                    ed.putInt("r_id", r);
                                    ed.commit();
                                    dialog();
                                    return true;
                                }
                            });
                            imgview.setOnClickListener(new View.OnClickListener() {
                                @Override
                                public void onClick(View v) {
                                    SharedPreferences sp = getSharedPreferences("profile", MODE_PRIVATE);
                                    SharedPreferences.Editor ed = sp.edit();
                                    String rid = String.valueOf(v.getTag());
                                    int r = Integer.parseInt(rid);
                                    ed.putInt("pic", r);
                                    ed.commit();
                                    Intent i = new Intent(getApplicationContext(), Profile_screen.class);
                                    startActivity(i);
                                }
                            });
                            a.addView(imgview);
                            a.addView(nm);
                            tab_lay1.addView(a, i);
                            i = i + 1;
                    }}
                } while (c.moveToNext());
            }
        } catch (Exception e) {
            Toast.makeText(getApplicationContext(), "NO DATA FOUND" + e.getMessage(), Toast.LENGTH_LONG).show();
        }
    }
    public void contacts(View v)
    {
        Intent i =new Intent(getApplicationContext(),Contacts.class);
        startActivity(i);
        finish();
    }

    public void dialog()
    {
        AlertDialog.Builder alert;
        alert = new AlertDialog.Builder(this);
        alert.setTitle("Delete Chat");
        alert.setMessage("Really Want To Delete This Chat");

        alert.setPositiveButton("Yes",new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                Toast.makeText(getApplicationContext(),"Yes",Toast.LENGTH_LONG).show();
                SharedPreferences sp = getSharedPreferences("chat", MODE_PRIVATE);
                int  r_id=sp.getInt("r_id",0);

                if(db.del_chat(s_id, r_id))
                {
                    Intent i = new Intent(getApplicationContext(),chat_display.class);
                    startActivity(i);
                    finish();
                }
            }
        });
        alert.setNegativeButton("No",new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                Toast.makeText(getApplicationContext(),"no",Toast.LENGTH_LONG).show();
            }
        });
        alert.show();
    }
}
