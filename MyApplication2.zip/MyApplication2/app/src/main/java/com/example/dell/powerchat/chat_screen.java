package com.example.dell.powerchat;

import android.app.ActionBar;
import android.content.Intent;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.graphics.Color;
import android.support.v7.app.ActionBarActivity;
import android.os.Bundle;
import android.view.Gravity;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.GridView;
import android.widget.Toast;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;

import static android.view.Gravity.RIGHT;
import static android.view.View.TEXT_DIRECTION_ANY_RTL;
import static android.view.View.TEXT_DIRECTION_RTL;
import static com.example.dell.powerchat.R.drawable.cbubble;


public class chat_screen extends ActionBarActivity {

    db_helper db;
private static int s_id=0;
private static int r_id;
    /*
    private string channelID = "CHANNEL ID_FROM_YOUR_SCALEDRONE_DASHBOARD";
    private String nameName = "observable room";
    private ScaleDrone scaledrone;*/
    EditText msg;
    String chat, nm;
    private ArrayList<String> list;
    private ArrayList<String> list1;
    private ArrayAdapter<String>adapter;
    Cursor c;
    int user;
    int chat_id=0;
    GridView gridview;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_chat_screen);
        db= new db_helper(this);
        gridview= (GridView)findViewById(R.id.gridView);
         list=new ArrayList<String>();
        list1=new ArrayList<String>();
        adapter=new ArrayAdapter<String>(getApplicationContext(), android.R.layout.simple_spinner_item,list);
        SharedPreferences sp = getSharedPreferences("chat", MODE_PRIVATE);
        r_id = sp.getInt("r_id", 0);
        nm = sp.getString("name","");
        SharedPreferences sp1 = getSharedPreferences("friends", MODE_PRIVATE);
        s_id  = sp1.getInt("s_id", 0 );
        msg = (EditText) findViewById(R.id.txt_msg);

        c= db.viewMsg(s_id,r_id);
        if(c.moveToNext())
        {
            do {
                user = c.getInt(c.getColumnIndex("chat_sid"));
                chat = c.getString(c.getColumnIndex("chat_msg"));
                chat_id = c.getInt(c.getColumnIndex("chat_id"));
                if (user == s_id) {
                    list.add("You:" + chat);
                } else {
                    list.add("       "+ nm + ": " + chat);
                }
                list1.add(Integer.toString(chat_id));

            }while (c.moveToNext());
            gridview.setAdapter(new ArrayAdapter<String>(this, android.R.layout.simple_list_item_1, list) {
                @Override
                public View getView(int position, View convertView, ViewGroup parent) {
                    View row = super.getView(position, convertView, parent);
                    if (getItem(position).contains("You")) {
                        row.setMinimumWidth(180);
                        row.setBackground(getDrawable(R.drawable.chat_round));
                        row.setTextAlignment(View.TEXT_ALIGNMENT_VIEW_END);

                    } else {
                        row.setMinimumWidth(100);
                        row.setBackgroundColor(Color.WHITE);
                        row.setBackground(getDrawable(R.drawable.chat2_round));
                        row.setTextAlignment(View.TEXT_ALIGNMENT_TEXT_END);
                    }


                    return row;
                }
            });
            gridview.smoothScrollToPosition(gridview.getCount());
        }

    }

    public void refresh(){
        gridview.setAdapter(new ArrayAdapter<String>(this, android.R.layout.simple_list_item_1, list){
        @Override
        public View  getView(int position,View convertView,ViewGroup parent)
        {
          View row = super.getView(position, convertView, parent);
            if (getItem(position).contains("You")) {
                row.setMinimumWidth(180);
                row.setBackground(getDrawable(R.drawable.chat_round));
                row.setTextAlignment(View.TEXT_ALIGNMENT_VIEW_END);

            } else {
                row.setBackgroundColor(Color.WHITE);
                row.setBackground(getDrawable(R.drawable.chat2_round));
                row.setTextAlignment(View.TEXT_ALIGNMENT_TEXT_END);
            }

            return row;
        }
        }
        );
        gridview.smoothScrollToPosition(gridview.getCount());
    }
    public void btn_send(View v)
    {
        db_helper db = new db_helper(this);
       Date today = new Date();
        SimpleDateFormat format1 = new SimpleDateFormat("dd-MM-yyyy");
        String dateToStr = format1.format(today);
        SimpleDateFormat format2 = new SimpleDateFormat("hh:mm:ss");
        String timeToStr = format2.format(today);
      //  String timeToStr = "time";
        //String dateToStr = "date";

        String c_msg;
        c_msg = msg.getText().toString();
        if(db.message(s_id,r_id,c_msg,timeToStr,dateToStr))
        {
            list.clear();
            list1.clear();
            c=db.viewMsg(s_id,r_id);
            if(c.moveToFirst())
            {
                do {
                    user = c.getInt(c.getColumnIndex("chat_sid"));
                    chat = c.getString(c.getColumnIndex("chat_msg"));
                    chat_id = c.getInt(c.getColumnIndex("chat_id"));
                    if(user==s_id)
                    {
                        list.add("You:" + chat);

                    }
                    else
                    {
                        list.add("       "+ nm + ": " + chat);
                    }
                    list1.add(Integer.toString(chat_id));
                }while (c.moveToNext());
                msg.setText("");
                refresh();
            }
        }
        else
        {
            Toast.makeText(getApplicationContext(),"not inserted", Toast.LENGTH_LONG).show();
        }
    }
    /*
    * @override
    public void onOpen(Room room)
    {
        System.out.println("Connected to room);
    }
    @override
    public void onOpenFailure(Room room, Exception ex)
    {
    System.out.println(ex);
    }
        @override
        public void onMessage(Room room, com.scaledrone.lib.Message receivedMessage)
        {
            //stmt
        }
    */
}
