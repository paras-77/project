package com.example.dell.powerchat;

import android.content.Intent;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.support.v7.app.ActionBarActivity;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;


public class View_Profile extends ActionBarActivity {
    String r_nm, r_lnm,r_num,r_email;
    public static Cursor c;
    int s_id,r_id;
    db_helper db;
    TextView nm,lnm,num,email;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_view__profile);
        nm=(TextView)findViewById(R.id.textView9);
        lnm=(TextView)findViewById(R.id.textView10);
        num=(TextView)findViewById(R.id.textView11);
        email=(TextView)findViewById(R.id.textView12);
        SharedPreferences sp = getSharedPreferences("friends", MODE_PRIVATE);
        s_id = sp.getInt("s_id", 0);
        db = new db_helper(this);
        try {
            c = db.chatlist();
            if (c.moveToFirst()) {
                do {
                    r_id=c.getInt(c.getColumnIndex("r_id"));
                    r_nm=c.getString(c.getColumnIndex("r_nm"));
                    r_lnm=c.getString(c.getColumnIndex("r_lnm"));
                    r_num=c.getString(c.getColumnIndex("r_num"));
                    r_email=c.getString(c.getColumnIndex("r_email"));
                    if(s_id==r_id)
                    {
                        nm.setText(r_nm);
                        lnm.setText(r_lnm);
                        num.setText(r_num);
                        email.setText(r_email);
                    }

                } while (c.moveToNext());
            }
        } catch (Exception e) {
            Toast.makeText(getApplicationContext(), "NO DATA FOUND" + e.getMessage(), Toast.LENGTH_LONG).show();
        }
    }

    public void edit_profile(View v)
    {
        Intent i=new Intent(getApplicationContext(),Edit_profile.class);
        startActivity(i);
        finish();
    }
}
