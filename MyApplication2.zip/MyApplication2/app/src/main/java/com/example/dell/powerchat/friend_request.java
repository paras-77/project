package com.example.dell.powerchat;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.provider.ContactsContract;
import android.support.v7.app.ActionBarActivity;
import android.os.Bundle;
import android.view.Gravity;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TableLayout;
import android.widget.TableRow;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.GregorianCalendar;


public class friend_request extends ActionBarActivity {

    db_helper db;
    String r_nm, r_lnm,r_num;
    public static    Cursor c;
    int r_id;
    private ArrayList<String> num,name;
  // final int r_id=0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_friend_request);
        num=new ArrayList<String>();
        name=new ArrayList<String>();
        int j=0;
        Cursor phones = getContentResolver().query(ContactsContract.CommonDataKinds.Phone.CONTENT_URI, null,null,null, null);
        while (phones.moveToNext())
        {
            String str= phones.getString(phones.getColumnIndex(ContactsContract.CommonDataKinds.Phone.NUMBER));

            name.add(phones.getString(phones.getColumnIndex(ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME)));
            num.add(str.replaceAll("[-() ]", ""));
            j++;
        }
        phones.close();

        TableLayout tab_lay = (TableLayout) findViewById(R.id.tab_lay);
        db = new db_helper(this);
        int i = 0;
        byte[] blob;
        try
        {
            c=db.chatlists();
            if(c.moveToFirst())
            {
                do {
                   TableRow a = new TableRow(this);
                    TableRow.LayoutParams param = new TableRow.LayoutParams(TableRow.LayoutParams.FILL_PARENT,TableRow.LayoutParams.MATCH_PARENT,1.0f);
                    a.setLayoutParams(param);
                 //   r_nm = c.getString(c.getColumnIndex("r_nm"));
                 //   r_lnm = c.getString(c.getColumnIndex("r_lnm"));
                    r_num = c.getString(c.getColumnIndex("r_num"));
                    r_nm = c.getString(c.getColumnIndex("r_nm"));
                    r_lnm = c.getString(c.getColumnIndex("r_lnm"));
                    blob = c.getBlob(c.getColumnIndex("r_image"));
                    r_id =c.getInt(c.getColumnIndex("r_id"));
                    Toast.makeText(getApplicationContext(),String.valueOf(r_id),Toast.LENGTH_LONG).show();
                    for(int k=0;k<num.size();k++) {
                        if (r_num.equals(num.get(k).toString())) {


                            Bitmap bmp = BitmapFactory.decodeByteArray(blob, 0, blob.length);
                            TableRow.LayoutParams param1 = new TableRow.LayoutParams(100, 100);

                            Bitmap.createScaledBitmap(bmp, 50, 50, true);
                            final ImageView imgview = new ImageView(this);
                            imgview.setId(i);
                            imgview.setImageBitmap(bmp);
                            imgview.setTag(r_id);
                            imgview.setLayoutParams(param1);
                           final TextView nm = new TextView(this);
                            nm.setText(r_nm + "   " + r_lnm);
                            nm.setTag(r_id);
                            nm.setId(i);
                            nm.setTextColor(Color.DKGRAY);
                            nm.setOnClickListener(new View.OnClickListener() {
                                @Override
                                public void onClick(View v) {
                                    SharedPreferences sp = getSharedPreferences("chat", MODE_PRIVATE);
                                    SharedPreferences.Editor ed = sp.edit();
                                    String rid=String.valueOf(v.getTag());
                                    int r=Integer.parseInt(rid);
                                    ed.putInt("r_id", r);
                                    ed.putString("name",r_nm);
                                    ed.commit();
                                    Intent i = new Intent(getApplicationContext(), chat_screen.class);
                                    startActivity(i);
                                }
                            });
                            imgview.setOnClickListener(new View.OnClickListener() {
                                @Override
                                public void onClick(View v) {
                                    SharedPreferences sp = getSharedPreferences("profile", MODE_PRIVATE);
                                    SharedPreferences.Editor ed = sp.edit();
                                    String rid=String.valueOf(v.getTag());
                                    int r=Integer.parseInt(rid);
                                    ed.putInt("pic", r);
                                    ed.commit();
                                  //  Toast.makeText(getApplicationContext(),rid,Toast.LENGTH_SHORT).show();
                                    Intent i = new Intent(getApplicationContext(), Profile_screen.class);
                                    startActivity(i);
                                }
                            });
                            a.addView(imgview);
                            a.addView(nm);
                            tab_lay.addView(a, i);
                            i = i + 1;
                        }
                    }
                }while(c.moveToNext());
            }
        }catch(Exception e)
        {
            Toast.makeText(getApplicationContext(),"NO DATA FOUND"+e.getMessage(), Toast.LENGTH_LONG).show();
        }
    }
}
