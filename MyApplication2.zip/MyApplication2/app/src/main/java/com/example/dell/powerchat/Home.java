package com.example.dell.powerchat;

import android.app.ActionBar;
import android.app.Activity;
import android.app.TabActivity;
import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.support.v7.app.ActionBarActivity;
import android.support.v7.internal.widget.AppCompatPopupWindow;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.TabHost;
import android.widget.TabHost.TabSpec;

public class Home extends TabActivity {


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);
        TabHost tabHost = getTabHost();
        tabHost.setBackground(new ColorDrawable(Color.DKGRAY));
        String tab1,tab2,tab3;
        tab1="Chats";
        tab2="Status";
        tab3="Settings";
        this.setNewTab(this, tabHost, "tab1", tab1, android.R.drawable.star_on, chat_display.class);
        this.setNewTab(this, tabHost, "tab2", tab2, android.R.drawable.star_on, status.class);
        this.setNewTab(this, tabHost, "tab3", tab3, android.R.drawable.star_on, Settings.class);
        tabHost.getTabWidget().getChildTabViewAt(0).setBackgroundColor(Color.parseColor("#FF02A4EE"));
        tabHost.getTabWidget().getChildTabViewAt(1).setBackgroundColor(Color.parseColor("#FF02A4EE"));
        tabHost.getTabWidget().getChildTabViewAt(2).setBackgroundColor(Color.parseColor("#FF02A4EE"));
    }
    private void setNewTab(Context context, TabHost tabHost, String tag, String title, int icon, Class contentID ){
        TabSpec tabSpec = tabHost.newTabSpec(tag);
        String titleString = title;
        tabSpec.setIndicator(titleString, context.getResources().getDrawable(android.R.drawable.star_on));
        tabSpec.setContent(new Intent(this, contentID));

        tabHost.addTab(tabSpec);
    }
}