    package com.example.dell.powerchat;

    import android.content.Intent;
    import android.database.sqlite.SQLiteDatabase;
    import android.graphics.Bitmap;
    import android.graphics.BitmapFactory;
    import android.net.Uri;
    import android.support.v7.app.ActionBarActivity;
    import android.os.Bundle;
    import android.view.Menu;
    import android.view.MenuItem;
    import android.view.View;
    import android.widget.EditText;
    import android.widget.ImageView;
    import android.widget.Toast;

    import java.io.ByteArrayInputStream;
    import java.io.ByteArrayOutputStream;
    import java.io.FileNotFoundException;
    import java.io.InputStream;


    public class registery extends ActionBarActivity {
        Boolean flag = true;
        EditText txt_nm,txt_lnm,txt_num,txt_email,txt_pwd ;


        db_helper db;
        SQLiteDatabase database;
        public byte[] byteArray;
        boolean UserValid=true;
        private static int RESULT_LOAD_IMAGE = 1;
        ImageView imag;

        @Override
        protected void onCreate(Bundle savedInstanceState) {
            super.onCreate(savedInstanceState);
            setContentView(R.layout.activity_registery);
            imag=(ImageView) findViewById(R.id.imageView5);

            db=new db_helper(this);
            database = db.getWritableDatabase();
            txt_nm =(EditText)findViewById(R.id.txt_nm);
            txt_lnm =(EditText)findViewById(R.id.txt_lnm);
            txt_num=(EditText)findViewById(R.id.txt_num);
            txt_email =(EditText)findViewById(R.id.txt_email);
            txt_pwd =(EditText)findViewById(R.id.txt_pwd);



        }
        public void register(View v)
        {
            String nm,lnm,num,email,pwd;
            nm= String.valueOf(txt_nm.getText());
            lnm=String.valueOf(txt_lnm.getText());
            num=String.valueOf(txt_num.getText());
            email=String.valueOf(txt_email.getText());
            pwd=txt_pwd.getText().toString();
            String emailPattern = "[a-zA-Z0-9._-]+@[a-z]+\\.+[a-z]+";

            if(nm.isEmpty())
            {
                txt_nm.setError("Please Enter your Name");
                flag=false;
            }
            if(lnm.isEmpty())
            {
                txt_lnm.setError("Please Enter your Last Name");
                flag = false;
            }
            if(email.isEmpty())
            {
                txt_email.setError("Please Enter your Email");
                flag = false;
            }
            else if(!email.matches(emailPattern))
            {
                txt_email.setError("Please Enter a Valid Email");
                flag = false;
            }
            if(pwd.isEmpty())
            {
                txt_pwd.setError("Please Enter your Password");
                flag = false;
            }
            else
            {
                flag = true;
            }
            if(flag==true) {


                if (db.AddData(nm, lnm, num, email, pwd, byteArray)) {
                    Intent i = new Intent(getApplicationContext(), log_in.class);
                    startActivity(i);
                } else {
                    Toast.makeText(getApplicationContext(), "ERROR IN REGISTER,,,,", Toast.LENGTH_LONG).show();
                }

            }
        }
        public void profile_pic(View v)
        {
            Intent getImageIntent = new Intent(Intent.ACTION_GET_CONTENT);
            getImageIntent.setType("image/*");
            startActivityForResult(getImageIntent, RESULT_LOAD_IMAGE);

        }
        @Override
        public void onActivityResult(int requestCode, int resultCode, Intent data)
        {
            if(requestCode==RESULT_LOAD_IMAGE&&resultCode==RESULT_OK)
            {
                try
                {
                    final Uri uriImage = data.getData();
                    final InputStream inputStream = getContentResolver().openInputStream(uriImage);
                    final Bitmap imageMap = BitmapFactory.decodeStream(inputStream);
                    imag.setImageBitmap(imageMap);
                    ByteArrayOutputStream stream = new ByteArrayOutputStream();
                    Bitmap.createScaledBitmap(imageMap,50,50,true);
                    imageMap.compress(Bitmap.CompressFormat.JPEG,10,stream);
                    byteArray = stream.toByteArray();

                }
                catch(FileNotFoundException e)
                {
                    e.printStackTrace();
                    Toast.makeText(getApplicationContext(), "Image was not found", Toast.LENGTH_SHORT).show();

                }
            }
        }


    }