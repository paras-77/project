package com.example.dell.powerchat;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.database.sqlite.SQLiteDatabase;
import android.support.v7.app.ActionBarActivity;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Toast;


public class Settings extends ActionBarActivity {

    db_helper db;
    SQLiteDatabase mydb;
    private static int r_id;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_settings);

    }
    public void delete(View v)
    {
        db_helper db= new db_helper(this);
        mydb=db.getWritableDatabase();
        SharedPreferences sp =getSharedPreferences("friends", MODE_PRIVATE);
        r_id = sp.getInt("s_id",0);
        boolean i = db.delete(r_id);
        if(i==true)
        {
            Toast.makeText(getApplicationContext(),"record deleted", Toast.LENGTH_LONG).show();
            Intent in = new Intent(getBaseContext(), log_in.class);

            startActivity(in);
        }
    }

    public void view(View v)
    {
        Intent i=new Intent(getBaseContext(),View_Profile.class);
        startActivity(i);
    }

    public void logout(View v)
    {
        SharedPreferences sp =getSharedPreferences("friends", MODE_PRIVATE);
        SharedPreferences.Editor ed=sp.edit();
        ed.clear();
        ed.commit();
        Intent i=new Intent(getBaseContext(),log_in.class);
        startActivity(i);
        finish();
    }
}
