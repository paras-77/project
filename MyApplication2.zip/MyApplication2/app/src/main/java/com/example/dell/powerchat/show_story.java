package com.example.dell.powerchat;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.Drawable;
import android.os.CountDownTimer;
import android.support.v7.app.ActionBarActivity;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.widget.ImageSwitcher;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.TableRow;
import android.widget.TextView;
import android.widget.Toast;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.BitSet;
import java.util.Timer;
import java.util.TimerTask;


public class show_story extends ActionBarActivity {
    db_helper db;
    ProgressBar pg;
    public static Cursor c;
    ArrayList<byte[]> img;
    public int currentIndex = 0;
    ImageView i;
    byte[] blob;
    public static int time=0;
    CountDownTimer cd;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_show_story);
        db = new db_helper(this);
        i = (ImageView) findViewById(R.id.imageView6);
        pg=(ProgressBar)findViewById(R.id.progressBar);
        img = new ArrayList<byte[]>();
        SharedPreferences sp = getSharedPreferences("profile", MODE_PRIVATE);
        int id = sp.getInt("status", 0);

        try {
            c = db.view_story(id);
                if (c.moveToFirst()) {
                    do {
                        blob = c.getBlob(c.getColumnIndex("status_image"));
                        int status_id=c.getInt(c.getColumnIndex("status_id"));
                      //  Toast.makeText(getApplicationContext(),String.valueOf(status_id),Toast.LENGTH_LONG).show();
                        img.add(blob);

                    } while (c.moveToNext());
                }

        } catch (Exception e) {
            Toast.makeText(getApplicationContext(), "NO DATA FOUND" + e.getMessage(), Toast.LENGTH_LONG).show();
        }
      //time=0;

        final int total = img.size();
        final Timer t = new Timer();
        t.scheduleAtFixedRate(new TimerTask() {

            public void run() {

                pg.setProgress(0);
                runOnUiThread(new Runnable() {
                    public void run() {

                        if(currentIndex==total)
                        {
                            t.cancel();
                            t.purge();
                            Intent i=new Intent(getApplicationContext(),status.class);
                            startActivity(i);
                            finish();
                        }
                        else{
                           byte[] data = img.get(currentIndex);
                            Bitmap bmp = BitmapFactory.decodeByteArray(data, 0, data.length);
                            i.setImageBitmap(bmp);
                            currentIndex++;
                            time=time+10;
                            pg.setProgress(time);
                        }
                    }
                });
            }
        }, 0, 5000);
    }
}